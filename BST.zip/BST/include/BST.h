#ifndef BST_H
#define BST_H
#include<iostream>
#include<bits/stdc++.h>
#include<string>
#include "Task.h"
#include <conio.h>
#include <stdlib.h>
using namespace std;
struct node
    {
       Task element;
        node *left;
        node *right;
    };

class BST
{
public:

    BST();
    BST(node* root);
    bool isEmpty();
    Task task_arr[1000];
    void sortbypr();
    void Insert(string t,int pr);
    void Insert(Task task);
    void Search(string name);
    void sortbypr(string t,int pr);
    void print(node* p);
    void printpr();
    void deleteroot(node* &p);
    void deleteroot();
    void clear();
    void clear(node* &p);
    void print();
    ~BST();


protected:

private:
    node* root;
    int size;


    //node *root;
};

#endif // DLL_H
