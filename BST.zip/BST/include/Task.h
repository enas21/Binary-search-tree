#ifndef TASK_H
#define TASK_H
#include<iostream>
#include<bits/stdc++.h>
#include<string.h>
using namespace std;
class Task
{
    private:
       string Name;
       int Priority;
    public:
       Task();
       void set_name(string name);
       void set_priority(int priority);
       string get_name();
       int get_priority();
       virtual ~Task();

    protected:


};

#endif // TASK_H
