#include <iostream>
#include<string>
#include <fstream>
#include <bits/stdc++.h>
#include "Task.h"
#include "BST.h"
#include <conio.h>
#include <stdlib.h>
using namespace std;

int main()
{
    BST b;

    int choice;
    string name;
    int priority;
    do
    {
        cout<<"Welcome to FCI BINARY SEARCH TREE"<<endl;
        cout<<"---------------------------------------- "<<endl;
        cout<<"1- loads the tasks into the tree sorted by name\n";
        cout<<"2- list all tasks sorted by priority\n";
        cout<<"3- Search Task\n";
        cout<<"4- retrieve and remove the top priority\n";
        cout<<"5- Print All Tasks\n";
        cout<<"6- EXIT\n";
        cout<<"ENTER YOUR CHOICE : ";
        cin>>choice;
        switch(choice)
        {
        case 1:
        {
            b.clear();
            Task task;
            fstream myfile;
            myfile.open("Task.txt",ios::in);
            string line;
            string Name;
            int Priority;
            if(myfile.fail())
            {
                cout<<"File was not found\n";
            }
            getline(myfile,line);

            while(myfile>>Name>>Priority)
            {
                task.set_name(Name);
                task.set_priority(Priority);
                b.Insert(Name,Priority);
                // cout<<task.get_name()<<setw(10);
                //  cout<<task.get_priority()<<endl;
            }
            break;
        }
        case 2:
        {
            b.clear();
            Task task;
            fstream myfile;
            myfile.open("Task.txt",ios::in);
            string line;
            string Name;
            int Priority;
            if(myfile.fail())
            {
                cout<<"File was not found\n";
            }
            getline(myfile,line);

            while(myfile>>Name>>Priority)
            {
                task.set_name(Name);
                task.set_priority(Priority);
                b.sortbypr(Name,Priority);
                // cout<<task.get_name()<<setw(10);
                //  cout<<task.get_priority()<<endl;
            }
            break;
        }
        case 3:
        {
            b.clear();
            Task task;
            fstream myfile;
            myfile.open("Task.txt",ios::in);
            string line;
            string Name;
            int Priority;
            if(myfile.fail())
            {
                cout<<"File was not found\n";
            }
            getline(myfile,line);

            while(myfile>>Name>>Priority)
            {
                task.set_name(Name);
                task.set_priority(Priority);
                b.Insert(Name,Priority);
                // cout<<task.get_name()<<setw(10);
                //  cout<<task.get_priority()<<endl;
            }
            cout<<"ENTER YOUR Task's Name YOU WANT TO Search"<<endl;
            cin>>name;
            b.Search(name);
            break;
        }
        case 4:
        {
            b.clear();
            Task task;
            fstream myfile;
            myfile.open("Task.txt",ios::in);
            string line;
            string Name;
            int Priority;
            if(myfile.fail())
            {
                cout<<"File was not found\n";
            }
            getline(myfile,line);

            while(myfile>>Name>>Priority)
            {
                task.set_name(Name);
                task.set_priority(Priority);
                b.sortbypr(Name,Priority);
            }
            b.deleteroot();
            break;
        }

        case 5:
        {
            b.print();
            break;
        }
        case 6:
        {
            cout<<"GOODBYE"<<endl;
            break;
        }
        default :
        {
            cout<<"you have entered invalid number , please try again\n";
        }
        }
    }
    while(choice!=6);

}
