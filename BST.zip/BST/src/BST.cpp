#include "BST.h"
#include <string>
#include <iostream>
#include <iomanip>
#include <conio.h>
#include <stdlib.h>
#include "Task.h"
using namespace std;
BST::BST()
{
    root=NULL;
    //left=right=NULL;
    size=-1;
}
//BST::BST(node* root)
//{
  //  root->left=NULL;
    //root->right=NULL;
//}
bool BST::isEmpty()
{
    return(root==NULL);
}
void BST::Insert(Task task)
{
    node* newnode=new node;
    size++;
    if(root==NULL)
    {

    }
   // task_arr[size].set_priority(pr);
   // task_arr[size].set_name(t);
}
void BST::Insert(string t,int pr)
{
   // clear();
    node* current=new node;
    node* trail=new node;
    node* newnode=new node;
    newnode->element.set_name(t);
    newnode->element.set_priority(pr);
    newnode->left = NULL;
    newnode->right = NULL;
    if(root==NULL)
    {
        size++;
    task_arr[size].set_priority(pr);
    task_arr[size].set_name(t);
    root=newnode;
    }
    else
    {
        current=root;
        while(current != NULL)
       {
           trail = current;

           if(current->element.get_name() == t)
           {
              cout<<"The insert item is already in the list -- ";
              cout<<"duplicates are not allowed."<<endl;
              return;
           }
           else
              if(current->element.get_name() > t)
                 current = current->left;
              else
                 current = current->right;
       }//end while

       if(trail->element.get_name() > t)
       {
           size++;
    task_arr[size].set_priority(pr);
    task_arr[size].set_name(t);
          trail->left = newnode;
       }
       else
       {
           size++;
    task_arr[size].set_priority(pr);
    task_arr[size].set_name(t);

          trail->right = newnode;
       }
    }
}
void BST::Search(string name)
{
    node *current = root;

	while(current != NULL)
	{
		if(current->element.get_name() == name)
        {
			cout<<"We Found It :"<<endl<<"Name : "<<current->element.get_name()<<"       "<<"Priority : "<<current->element.get_priority()<<endl;
			break;
        }
		else if(current->element.get_name() > name)
			current = current->left;
        else
            current = current->right;
	}
if(current=NULL)
    cout<<"Not Found ."<<endl;
}
void BST::sortbypr()
{
    for(int i=0;i<=size;i++)
        sortbypr(task_arr[i].get_name(),task_arr[i].get_priority());
}
void BST::sortbypr(string t,int pr)
{
   // clear();
    node* current=new node;
    node* trail=new node;
    node* newnode=new node;
    newnode->element.set_name(t);
    newnode->element.set_priority(pr);
    newnode->left = NULL;
    newnode->right = NULL;
    if(root==NULL)
    {
    size++;
    task_arr[size].set_priority(pr);
    task_arr[size].set_name(t);
    root=newnode;
    }
    else
    {
        current=root;
        while(current != NULL)
       {
           trail = current;

           if(current->element.get_name() == t)
           {
              cout<<"The insert item is already in the list -- ";
              cout<<"duplicates are not allowed."<<endl;
              return;
           }
           else
              if(current->element.get_priority() > pr)
                 current = current->left;
              else
                 current = current->right;
       }//end while

       if(trail->element.get_priority() > pr)
       {
           size++;
    task_arr[size].set_priority(pr);
    task_arr[size].set_name(t);
          trail->left = newnode;
       }
       else
       {
          size++;
    task_arr[size].set_priority(pr);
    task_arr[size].set_name(t);
          trail->right = newnode;
       }
    }
}
void BST::deleteroot(node* &p)
{
     node *current=new node;    //pointer to traverse
                                     //the tree
     node *trailCurrent=new node;   //pointer behind current
     node *temp=new node;        //pointer to delete the node

	 if(p->left == NULL && p->right == NULL)
     {
		delete p;
		p = NULL;
     }
     else if(p->left == NULL)
     {
		temp = p;
        p = p->right;
        delete temp;
     }
     else if(p->right == NULL)
     {
		temp = p;
        p = p->left;
        delete temp;
     }
     else
     {
        current = p->left;
        trailCurrent = NULL;

        while(current->right != NULL)
        {
            trailCurrent = current;
            current = current->right;
        }//end while

        p->element = current->element;

        if(trailCurrent == NULL) //current did not move;
                                 //current == p->left; adjust p
           p->left = current->left;
        else
           trailCurrent->right = current->left;

        delete current;
     }
}
void BST::deleteroot()
{
    cout<<"Top Priority is : "<<root->left->left->element.get_priority()<<endl;
    deleteroot(root->left->left);
    cout<<"Now it's deleted."<<endl;
}
void BST::print(node* p)
{
    if(p != NULL)
	{
		print(p->left);
		cout<<p->element.get_name()<<"      "<<p->element.get_priority()<<endl;
		print(p->right);
	}
}
void BST::printpr()
{
    for(int i=0;i<=size;i++)
    {
        cout<<"Name :"<<task_arr[i].get_name()<<setw(20);
        cout<<"Priority :"<<task_arr[i].get_priority()<<endl;
    }
}
void BST::print()
{
    print(root);
}
void BST::clear(node* &p)
{
    if(p != NULL)
	{
		clear(p->left);
		clear(p->right);
		delete p;
		p = NULL;
	}
}
void BST::clear()
{
    clear(root);
}
BST::~BST()
{
   //clear(root);
}
